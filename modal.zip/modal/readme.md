Mapa Sigua en modal
===================


Esta utilidad permite utilizar en Internet la cartografía de SIGUA (http://www.sigua.ua.es) utilizando el framework Bootstrap de Twitter.

Su funcionamiento es muy sencillo y permite navegar por el mapa de forma continua, pudiendo además obtener información puntual sobre las estancias, con estos datos:
> - Actividad
> - Departamento
> - Denominación
> - Superficie
> - Ocupantes
> - Enlaces a redes sociales (Twitter, Facebook, G+)
> - Enlaces a visores cartográficos web (OpenStreetMap y GMaps)

Para navegar entre las diferentes plantas se utiliza un **control de plantas** que permite cambiar de una planta a otra

----------


Información
-------------

La cartografía se visualiza en una ventana modal cuyo tamaño es persolizable mediante CSS 
```
#map { min-height: 350px;}
```
Este  visor utiliza tres  librerías Javascript que pueden referirse de forma local (directorio **assets**) o remota:
> - **LeafletJS**: Pequeña pero potente utilidad para visualizar cartografía en la web
> - **Jquery**: Framework de sobra conocido para facilitar el uso de Javascript
> **Bootstrap:**Framework creado por Twitter para crear interfaces web con CSS. La versión utilizada es la 3.X

Aparte de dichas librerías, encontramos dos ficheros javascript que contienen la funcionalidad de Sigua (también en **assets/js**:
> - **sigua_capas.js**: Contiene la articulación de las capas cartográficas utilizadas.
> - **sigua_main_basico[1/2/3].html**: Contiene la funcionalidad de información, cambio de capas y demás funciones. Hay 3, uno para cada ejemplo.
Opcionalmente se utiliza **Font Awesome** para dibujar iconos

La información de carácter puntual es obtenida utilizando el API RestFul de Sigua: http://web.ua.es/es/sigua/api-rest.html

Para crear un modal de Sigua utiliza esta plantilla
```
<div class="modal" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button> 
                <h4 class="modal-title">Título</h4>
            </div>
            <div class="modal-body" id="map"></div>
            <div class="modal-footer">
               <div class="btn-group hide" data-toggle="buttons" id="plantas">
                  <span class="badge">Plantas</span>
		 <label class="btn btn-default"> <input type="radio" name="planta" id="P1" value="P1"> P1  </label>
		 <label class="btn btn-default"> <input type="radio" name="planta" id="P3" value="P3"> P3  </label>
		 <label class="btn btn-default"> <input type="radio" name="planta" id="PS" value="PS"> PS  </label>
	  </div>                
        </div>            
      </div>
    </div>
 </div>
```

Ejemplos
-------------
Hemos realizado tres diferentes  ejemplos con diferentes funcionalidades:


> - **index_basico1.html**: Es el modal más básico, con el mapa de la UA y la posibilidad de cambiar de planta. También puede obtener información de las estancias
> - **index_basico2.html**: Las mismas prestaciones que el anterior,  pero se dispone de un control de formulario tipo SELECT para obtener el listado de edificios. Cuando se selecciona uno se hace un zoom a su totalidad
> - **index_basico3.html:**: Al igual que el anterior, pero en este caso los edificios aparecen


Personalización
-------------
Sí quieres extender la funcionalidad cuando se selecciona una estancia en el popup (info), dispones de una función llamada **showCodigo** que recibe como variable el código de estancia. Puedes utilizarlo para incorporarlo a  tu website. Este evento se dispara haciendo clic en el botón del popup.
```
function showCodigo( codigo ) {
	alert("Hola, has seleccionado la estancia con codigo " + codigo );
} 
```
